# The Complicator

Code Authors: Grayson Boyer, Everett Shock
Data Compilers: GEOPIG Lab

Estimate thermodynamic properties of aqueous inorganic complexes with monovalent ligands.